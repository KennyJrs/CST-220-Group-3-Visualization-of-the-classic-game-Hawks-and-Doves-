#include "amount.h"
#include "ui_amount.h"

#include "r1.h"

#include <QMessageBox>


amount::amount(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::amount)
{
    ui->setupUi(this);
    connect(ui->ok, SIGNAL(clicked()), this, SLOT(ott()));
    setWindowTitle("Кількість раундів");
}

amount::~amount()
{
    delete ui;
}

void amount::ott()
{
    try {
        val = ui->lineEdit->text().toInt();
        if (val <= 0)
            throw 1;
        if (val > 10)
            throw 2;

        this->close();
        r1* ro1 = new r1(ui->lineEdit->text(), this);
        ro1->exec();
    }
    catch (int e) {
        if (e == 1)
            QMessageBox::about(this, "Помилка", "Введена кiлькiсть менше 1.");
        if (e == 2)
            QMessageBox::about(this, "Помилка", "Введена кiлькiсть бiльше 10.");
    }
}

