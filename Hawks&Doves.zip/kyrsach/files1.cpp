#include "files1.h"

#include <QFile>
#include <QVariantMap>
#include <QJsonDocument>
#include <QJsonObject>
#include <QStringList>
#include <QRandomGenerator>

files1::files1(QObject *parent) : QObject(parent)
{
    scoresfromjs();
    roundsfromjs();
}

void files1::set_pc_vids(int i)
{
    pc_vids = i;
}

void files1::set_pc_attack(int i)
{
    pc_attack = i;
}

void files1::set_me_vids(int i)
{
    me_vids = i;
}

void files1::set_me_attack(int i)
{
    me_attack = i;
}

void files1::set_rounds(int i)
{
    round = i;
}

QString files1::getfromjs()
{
    try {
     QStringList wordList;
     QFile f("D:/labs/kyrsach/resources/scores.json");

     if (!f.exists()){
         throw 1;
     }
     if (f.open(QIODevice::ReadOnly))
     {
        QString data1;
        data1 = f.readAll();
        wordList = data1.split('\n');
        f.close();

        QString str1 = wordList[3] + "\n" + wordList[4];
        return str1;
    }
    }
    catch (int e){
        exit(0);
    }
    return 0;
}

void files1::scoresfromjs()
{
    try {
    QStringList wordList;
     QFile f("D:/labs/kyrsach/resources/scores.json");

     if (!f.exists()){
         throw 1;
     }

       if (f.open(QIODevice::ReadOnly))
       {
            QString data1;
            data1 = f.readAll();
            QRegExp rx("[:,}]");
            wordList = data1.split(rx);
            f.close();
       }
       QString str1 = wordList[1] + " " + wordList[3] + " " + wordList[9] + " " + wordList[11];

       gen_me_bal += str1.split(" ")[1].toInt();
       gen_pc_bal += str1.split(" ")[3].toInt();
       pigeons += str1.split(" ")[5].toInt();
       hawks += str1.split(" ")[7].toInt();
    }
    catch (int e){
        exit(0);
    }
}

QString files1::fromcsv()
{
       try {
        QStringList wordList;
        QFile f(":/resources/1.csv");

        if (!f.exists()){
            throw 1;
        }

        if (f.open(QIODevice::ReadOnly)){
            QString data1;
            data1 = f.readAll();
            wordList = data1.split(';');
            f.close();
        }
        QString str4 = wordList[0]+wordList[2]+wordList[4]+wordList[6];
        return str4;

       }
       catch (int e){
            exit(0);
       }
    return 0;
}

void files1::point()
{
    QString str1 = fromcsv();

    if ((me_vids == 1)&&(pc_vids == 1)){
        me_bal = 0;
        me_bal = str1.split("\n")[0].toInt();

        pc_bal = 0;
        pc_bal = str1.split("\n")[0].toInt();

        gen_me_bal += str1.split("\n")[0].toInt();
        gen_pc_bal += str1.split("\n")[0].toInt();

        pigeons += 2;
    }
    if ((me_vids == 1)&&(pc_attack == 1)){
        me_bal = 0;
        pc_bal = 0;
        pc_bal = str1.split("\n")[2].toInt();

        gen_me_bal += 0;
        gen_pc_bal += str1.split("\n")[2].toInt();

        pigeons -= 1;
        hawks +=1;
    }
    if ((me_attack == 1)&&(pc_vids == 1)){
        me_bal = 0;
        me_bal = str1.split("\n")[2].toInt();
        pc_bal = 0;

        gen_pc_bal += 0;
        gen_me_bal += str1.split("\n")[2].toInt();

        pigeons -= 1;
        hawks +=1;
    }
    if ((me_attack == 1)&&(pc_attack == 1)){
        me_bal = 0;
        me_bal = str1.split("\n")[3].toInt();
        pc_bal = 0;
        pc_bal = str1.split("\n")[3].toInt();

        gen_pc_bal += str1.split("\n")[3].toInt();
        gen_me_bal += str1.split("\n")[3].toInt();

        hawks -= 2;
    }
}

void files1::comp_str()
{
    int k;
    k = QRandomGenerator::system()->bounded(1,10);
    if (k % 2 == 0){
        pc_vids = 1;
    }

    else if(k % 2 == 1) {
        pc_attack = 1;
    }
}

void files1::roundstojs()
{
    try{
        QFile fileJson("D:/labs/kyrsach/resources/rounds.json");
        if (!fileJson.exists()){
            throw 1;
        }

        if (fileJson.open(QIODevice::WriteOnly)){
            QVariantMap testMap;
            testMap.insert("Номер раунду на даний момент", round);
            fileJson.write(QJsonDocument(QJsonObject::fromVariantMap(testMap)).toJson());
            fileJson.close();
        }
    }

        catch (int e) {
            exit(0);
        }
}

int files1::roundsfromjs()
{
    try {
        QStringList wordList;
        QFile f("D:/labs/kyrsach/resources/rounds.json");
        if (!f.exists()){
            throw 1;
        }
        if (f.open(QIODevice::ReadOnly)){
            QString data1;
            data1 = f.readAll();
            QRegExp rx("[:}]");
            wordList = data1.split(rx);
            f.close();
        }
        QString str1 = wordList[1];
        return str1.toInt();
    }
    catch (int e){
        exit(0);
    }
    return 0;
}

void files1::tojs()
{
    try{
        QFile fileJson("D:/labs/kyrsach/resources/scores.json");
        if (!fileJson.exists()){
            throw 1;
        }

        if (fileJson.open(QIODevice::WriteOnly)){
            QVariantMap testMap;
            testMap.insert("Загальна кількість балів комп'ютера", gen_pc_bal);
            testMap.insert("Загальна кількість балів гравця", gen_me_bal);
            testMap.insert("Кількість балів комп'ютера", pc_bal);
            testMap.insert("Кількість балів гравця", me_bal);
            testMap.insert("Кількість голубів", pigeons);
            testMap.insert("Кількість яструбів", hawks);
            fileJson.write(QJsonDocument(QJsonObject::fromVariantMap(testMap)).toJson());
            fileJson.close();
        }
    }

        catch (int e) {
            exit(0);
        }
}
