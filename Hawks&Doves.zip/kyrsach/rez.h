#ifndef REZ_H
#define REZ_H

#include <QDialog>

namespace Ui {
class rez;
}

class rez : public QDialog
{
    Q_OBJECT

public:
    explicit rez(QWidget *parent = nullptr);
    ~rez();

private slots:
    QString rezr();

    QString rezgame();

    QString pigfromjs();

    void on_exit_clicked();

private:
    Ui::rez *ui;
};

#endif // REZ_H
