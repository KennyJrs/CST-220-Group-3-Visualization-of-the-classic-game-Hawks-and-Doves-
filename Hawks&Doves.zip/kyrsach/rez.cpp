#include "rez.h"
#include "ui_rez.h"

#include <QFile>
#include <QRegExp>
#include <QMessageBox>
#include <QVariantMap>
#include <QJsonObject>
#include <QJsonDocument>


rez::rez(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::rez)
{
    ui->setupUi(this);
    setWindowTitle("Результат гри");
    QString str1 = rezr();
    ui->yourmark->setText(str1.split(" ")[1]);
    ui->pcmark->setText(str1.split(" ")[2]);
    ui->label->setText(rezgame());
    ui->fromjs->setText(pigfromjs());
}

rez::~rez()
{
    delete ui;
}

QString rez::rezr()
{
    try {
      QStringList wordList;
      QFile f("D:/labs/kyrsach/resources/scores.json");

      if (!f.exists()){
          throw 1;
      }

        if (f.open(QIODevice::ReadOnly))
        {
            QString data1;
            data1 = f.readAll();
            QRegExp rx("[:,]");
            wordList = data1.split(rx);
            f.close();
         }
      QString str4 = wordList[1] + wordList[3];
      return str4;
    }
    catch (int e) {
        QMessageBox::about(this, "Помилка", "Файл не відкрився!");
        qApp->exit();
    }
    return 0;
}

QString rez::rezgame()
{
    try {
     QStringList wordList2;
     QFile f("D:/labs/kyrsach/resources/scores.json");

     if (!f.exists()){
         throw 1;
     }

       if (f.open(QIODevice::ReadOnly))
       {
            QString data1;
            data1 = f.readAll();
            QRegExp rx("[:,]");
            wordList2 = data1.split(rx);
            f.close();
       }
       QString str1 = wordList2[1] + " " + wordList2[3];
       if (str1.split(" ")[1].toInt() < str1.split(" ")[3].toInt())
       {
             QString str4 = "Ви програли!";
             return str4;
       }
       if (str1.split(" ")[1].toInt() > str1.split(" ")[3].toInt())
       {
             QString str4 = "Ви перемогли!";
             return str4;
       }
       if (str1.split(" ")[1].toInt() == str1.split(" ")[3].toInt())
       {
             QString str4 = "Перемогла дружба!";
             return str4;
       }
     }
    catch (int e){
        QMessageBox::about(this, "Помилка", "Файл не відкрився!");
        qApp->exit();
    }
    return 0;
}

 QString rez::pigfromjs()
 {
     try {
       QStringList wordList3;
         QFile f("D:/labs/kyrsach/resources/scores.json");

         if (!f.exists()){
             throw 1;
         }

         if (f.open(QIODevice::ReadOnly))
         {
             QString data1;
             data1 = f.readAll();
             wordList3 = data1.split("\n");
             f.close();
          }
        QString str4 = wordList3[5] + "\n" + wordList3[6];
        return str4;
     }
     catch (int e){
         QMessageBox::about(this, "Помилка", "Файл не відкрився!");
         qApp->exit();
     }
     return 0;
 }


void rez::on_exit_clicked()
{
    this->close();

    try {
        QFile fileJson("D:/labs/kyrsach/resources/scores.json");
        if (!fileJson.exists()){
            throw 1;
        }

        if (fileJson.open(QIODevice::WriteOnly)){
            QVariantMap testMap;
            testMap.insert("Загальна кількість балів комп'ютера", 0);
            testMap.insert("Загальна кількість балів гравця", 0);
            testMap.insert("Кількість балів комп'ютера", 0);
            testMap.insert("Кількість балів гравця", 0);
            testMap.insert("Кількість голубів", 0);
            testMap.insert("Кількість яструбів", 0);
            fileJson.write(QJsonDocument(QJsonObject::fromVariantMap(testMap)).toJson());
            fileJson.close();
        }
    }
    catch (int e){
        QMessageBox::about(this, "Помилка", "Файл не відкрився!");
        qApp->exit();
    }

    try {
        QFile fileJson("D:/labs/kyrsach/resources/rounds.json");
        if (!fileJson.exists()){
            throw 1;
        }

        if (fileJson.open(QIODevice::WriteOnly)){
            QVariantMap testMap;
            testMap.insert("Номер раунду на даний момент", 1);
            fileJson.write(QJsonDocument(QJsonObject::fromVariantMap(testMap)).toJson());
            fileJson.close();
        }
    }
    catch (int e){
        QMessageBox::about(this, "Помилка", "Файл не відкрився!");
        qApp->exit();
    }

}

