#ifndef FILES1_H
#define FILES1_H

#include <QObject>

class files1 : public QObject
{
    Q_OBJECT
public:
    explicit files1(QObject *parent = nullptr);

    void set_pc_vids(int i);
    void set_pc_attack(int i);
    void set_me_vids(int i);
    void set_me_attack(int i);
    void set_rounds(int i);

    QString getfromjs();
    void scoresfromjs();
    QString fromcsv();
    void tojs();

    void point();
    void comp_str();

    void roundstojs();
    int roundsfromjs();


private:
int me_bal,pc_bal,gen_me_bal=0,gen_pc_bal=0,pigeons=0,hawks=0,pc_vids,pc_attack,me_vids,me_attack,round=1;
};

#endif // FILES1_H
