#ifndef R1_H
#define R1_H

#include <QDialog>

#include "files1.h"

namespace Ui {
class r1;
}

class r1 : public QDialog
{
    Q_OBJECT

public:
    explicit r1( QString data, QWidget *parent = nullptr);
    ~r1();

private slots:
    void on_vids_clicked();

    void on_atack_clicked();

private:
    int n;
    QString nstr;

    Ui::r1 *ui;
    files1 *Files1;
};

#endif // R1_H
