#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "info.h"
#include "amount.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("Головне меню");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_play_clicked()
{
    amount amo;
    amo.setModal(true);
    amo.exec();
    this->close();
}


void MainWindow::on_close_clicked()
{
    this->close();
}


void MainWindow::on_info_clicked()
{
    info i;
    i.setModal(true);
    i.exec();
}

