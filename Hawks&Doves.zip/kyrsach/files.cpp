#include "files.h"

#include <QFile>
#include <QVariantMap>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMessageBox>
#include <QStringList>
#include <QRandomGenerator>

files::files()
{
    /*files *Files = new files;
    Files->set_me_vids(1);
    QMessageBox::about(this, "me_vids", QString::number(Files->get_me_vids()));
    //me_vids = 1;
    comp_str();
    //Files->point();
    //zac();
    //files *F = new files(1);
    Files->set_me_vids(0);
   // me_vids = 0;
    QMessageBox::about(this, "me_vids", QString::number(Files->get_me_vids()));
    Files->set_pc_vids(0);
   // pc_vids = 0;
    Files->set_pc_attack(0);
    //pc_atak = 0;
    Files->tojs();
   // tojs();
    delete Files;*/

    //me_vids = 1;

    //files *Files = new files;
   /* int k;
    k = QRandomGenerator::system()->bounded(1,10);
    if (k % 2 == 0){
        pc_vids = 1;
        //QMessageBox::about(this, "pc_vids", QString::number(Files->get_pc_vids()));
        //pc_vids = 1;
    }
    else if(k % 2 == 1) {
        //Files->set_pc_attack(1);
        //QMessageBox::about(this, "pc_attack", QString::number(Files->get_pc_attack()));
        pc_attack = 1;
    }
    //delete Files;*/



   /* QStringList wordList,wordList1;
       // try {
        QFile f("D:/shitforme/labs/1.csv");
       /* if (!f.exists()){
            throw 1;
        }*/
        /*if (f.open(QIODevice::ReadOnly)){
        QString data1;
        data1 = f.readAll();
        wordList = data1.split(';');
        f.close();
        }
        QString str4 = wordList[0]+wordList[2]+wordList[4]+wordList[6];*/




        /*if ((me_vids == 1)&&(pc_vids == 1)){
            me_bal = 0;
            me_bal = str4.split("\n")[0].toInt();

            pc_bal = 0;
            pc_bal = str4.split("\n")[0].toInt();

            gen_me_bal += me_bal;
            gen_pc_bal += pc_bal;

            pigeons += 2;
        }
        if ((me_vids == 1)&&(pc_attack == 1)){
            me_bal = 0;
            pc_bal = 0;
            pc_bal = str4.split("\n")[2].toInt();

            gen_me_bal += me_bal;
            gen_pc_bal += pc_bal;

            pigeons -= 1;
            hawks +=1;
        }
        if ((me_attack == 1)&&(pc_vids == 1)){
            me_bal = 0;
            me_bal = str4.split("\n")[2].toInt();
            pc_bal = 0;

            gen_pc_bal += pc_bal;
            gen_me_bal += me_bal;

            pigeons -= 1;
            hawks +=1;
        }
        if ((me_attack == 1)&&(pc_attack == 1)){
            me_bal = 0;
            me_bal = str4.split("\n")[3].toInt();
            pc_bal = 0;
            pc_bal = str4.split("\n")[3].toInt();

            gen_pc_bal += pc_bal;
            gen_me_bal += me_bal;

            hawks -= 2;
        }


        me_vids = 0;
        pc_vids = 0;
        pc_attack = 0;




        QFile fileJson("D:/shitforme/labs/2.json");

       /* if (!fileJson.exists()){
            throw 1;
        }*/

        /*if (fileJson.open(QIODevice::WriteOnly)){
        QVariantMap testMap;
        testMap.insert("Загальна кількість балів комп'ютера", gen_pc_bal);
        testMap.insert("Загальна кількість балів гравця", gen_me_bal);
        testMap.insert("Кількість балів комп'ютера", pc_bal);
        testMap.insert("Кількість балів гравця", me_bal);
        testMap.insert("Кількість голубів", pigeons);
        testMap.insert("Кількість яструбів", hawks);
        fileJson.write(QJsonDocument(QJsonObject::fromVariantMap(testMap)).toJson());
        fileJson.close();
        }*/

}

files::~files()
{

}

int files::get_me_bal()
{
    return me_bal;
}

int files::get_pc_bal()
{
    return pc_bal;
}

int files::get_gen_me_bal()
{
    return gen_me_bal;
}

int files::get_gen_pc_bal()
{
    return gen_pc_bal;
}

int files::get_pigeons()
{
    return pigeons;
}

int files::get_hawks()
{
    return hawks;
}

int files::get_pc_vids()
{
    return pc_vids;
}

int files::get_pc_attack()
{
    return pc_attack;
}

int files::get_me_vids()
{
    return me_vids;
}

int files::get_me_attack()
{
    return me_attack;
}

void files::set_pc_vids(int i)
{
    pc_vids = i;
}

void files::set_pc_attack(int i)
{
    pc_attack = i;
}

void files::set_me_vids(int i)
{
    me_vids = i;
}

void files::set_me_attack(int i)
{
    me_attack = i;
}

void files::set_pigeons(int i)
{
    pigeons += i;
}

void files::set_hawks(int i)
{
    hawks += i;
}

void files::set_me_bal(int i)
{
    me_bal = i;
}

void files::set_pc_bal(int i)
{
    pc_bal = i;
}

void files::set_gen_me_bal(int i)
{
    gen_me_bal += i;
}

void files::set_gen_pc_bal(int i)
{
    gen_pc_bal += i;
}


QString files::getfromjs()
{
   // try {
    QStringList wordList,wordList1;
     QFile f("D:/shitforme/labs/2.json");

     /*if (!f.exists()){
         throw 1;
     }*/

       if (f.open(QIODevice::ReadOnly))
       {
            QString data1;
            data1 = f.readAll();
            wordList = data1.split('\n');
            f.close();
       }
       QString str1 = wordList[3] + "\n" + wordList[4];
       return str1;
    //}
   /* catch (int e){
        QMessageBox::about(this, "Помилка", "Файл не відкрився!");
        qApp->exit();
    }*/
   // return 0;
}

QString files::fromcsv()
{
    QStringList wordList,wordList1;


       // try {
        QFile f("D:/shitforme/labs/1.csv");
       /* if (!f.exists()){
            throw 1;
        }*/
        if (f.open(QIODevice::ReadOnly)){
        QString data1;
        data1 = f.readAll();
        wordList = data1.split(';');
        f.close();
        }
        QString str4 = wordList[0]+wordList[2]+wordList[4]+wordList[6];
        return str4;

      // }
        /* catch (int e){
            QMessageBox::about(this, "Помилка", "Файл не відкрився!");
            qApp->exit();
         }*/
   // return 0;
}

void files::point()
{
    QString str1 = fromcsv();

    if ((me_vids == 1)&&(pc_vids == 1)){
        me_bal = 0;
        me_bal = str1.split("\n")[0].toInt();

        pc_bal = 0;
        pc_bal = str1.split("\n")[0].toInt();

        gen_me_bal += me_bal;
        gen_pc_bal += pc_bal;

        pigeons += 2;
    }
    if ((me_vids == 1)&&(pc_attack == 1)){
        me_bal = 0;
        pc_bal = 0;
        pc_bal = str1.split("\n")[2].toInt();

        gen_me_bal += me_bal;
        gen_pc_bal += pc_bal;

        pigeons -= 1;
        hawks +=1;
    }
    if ((me_attack == 1)&&(pc_vids == 1)){
        me_bal = 0;
        me_bal = str1.split("\n")[2].toInt();
        pc_bal = 0;

        gen_pc_bal += pc_bal;
        gen_me_bal += me_bal;

        pigeons -= 1;
        hawks +=1;
    }
    if ((me_attack == 1)&&(pc_attack == 1)){
        me_bal = 0;
        me_bal = str1.split("\n")[3].toInt();
        pc_bal = 0;
        pc_bal = str1.split("\n")[3].toInt();

        gen_pc_bal += pc_bal;
        gen_me_bal += me_bal;

        hawks -= 2;
    }
}

void files::comp_str()
{
    int k;
    k = QRandomGenerator::system()->bounded(1,10);
    if (k % 2 == 0){
        pc_vids = 1;
        //QMessageBox::about(this, "pc_vids", QString::number(Files->get_pc_vids()));
        //pc_vids = 1;
    }

    else if(k % 2 == 1) {
        pc_attack = 1;
        //QMessageBox::about(this, "pc_attack", QString::number(Files->get_pc_attack()));
        //pc_atak = 1;
    }
}

void files::all()
{
    /*files *Files = new files;
    Files->set_me_vids(1);
    QMessageBox::about(this, "me_vids", QString::number(Files->get_me_vids()));
    //me_vids = 1;
    comp_str();
    //Files->point();
    //zac();
    //files *F = new files(1);
    Files->set_me_vids(0);
   // me_vids = 0;
    QMessageBox::about(this, "me_vids", QString::number(Files->get_me_vids()));
    Files->set_pc_vids(0);
   // pc_vids = 0;
    Files->set_pc_attack(0);
    //pc_atak = 0;
    Files->tojs();
   // tojs();
    delete Files;*/

    me_vids = 1;

    //files *Files = new files;
    int k;
    k = QRandomGenerator::system()->bounded(1,10);
    if (k % 2 == 0){
        pc_vids = 1;
        //QMessageBox::about(this, "pc_vids", QString::number(Files->get_pc_vids()));
        //pc_vids = 1;
    }
    else if(k % 2 == 1) {
        //Files->set_pc_attack(1);
        //QMessageBox::about(this, "pc_attack", QString::number(Files->get_pc_attack()));
        pc_attack = 1;
    }
    //delete Files;



    QStringList wordList,wordList1;
       // try {
        QFile f("D:/shitforme/labs/1.csv");
       /* if (!f.exists()){
            throw 1;
        }*/
        if (f.open(QIODevice::ReadOnly)){
        QString data1;
        data1 = f.readAll();
        wordList = data1.split(';');
        f.close();
        }
        QString str4 = wordList[0]+wordList[2]+wordList[4]+wordList[6];




        if ((me_vids == 1)&&(pc_vids == 1)){
            me_bal = 0;
            me_bal = str4.split("\n")[0].toInt();

            pc_bal = 0;
            pc_bal = str4.split("\n")[0].toInt();

            gen_me_bal += me_bal;
            gen_pc_bal += pc_bal;

            pigeons += 2;
        }
        if ((me_vids == 1)&&(pc_attack == 1)){
            me_bal = 0;
            pc_bal = 0;
            pc_bal = str4.split("\n")[2].toInt();

            gen_me_bal += me_bal;
            gen_pc_bal += pc_bal;

            pigeons -= 1;
            hawks +=1;
        }
        if ((me_attack == 1)&&(pc_vids == 1)){
            me_bal = 0;
            me_bal = str4.split("\n")[2].toInt();
            pc_bal = 0;

            gen_pc_bal += pc_bal;
            gen_me_bal += me_bal;

            pigeons -= 1;
            hawks +=1;
        }
        if ((me_attack == 1)&&(pc_attack == 1)){
            me_bal = 0;
            me_bal = str4.split("\n")[3].toInt();
            pc_bal = 0;
            pc_bal = str4.split("\n")[3].toInt();

            gen_pc_bal += pc_bal;
            gen_me_bal += me_bal;

            hawks -= 2;
        }


        me_vids = 0;
        pc_vids = 0;
        pc_attack = 0;




        QFile fileJson("D:/shitforme/labs/2.json");

       /* if (!fileJson.exists()){
            throw 1;
        }*/

        if (fileJson.open(QIODevice::WriteOnly)){
        QVariantMap testMap;
        testMap.insert("Загальна кількість балів комп'ютера", gen_pc_bal);
        testMap.insert("Загальна кількість балів гравця", gen_me_bal);
        testMap.insert("Кількість балів комп'ютера", pc_bal);
        testMap.insert("Кількість балів гравця", me_bal);
        testMap.insert("Кількість голубів", pigeons);
        testMap.insert("Кількість яструбів", hawks);
        fileJson.write(QJsonDocument(QJsonObject::fromVariantMap(testMap)).toJson());
        fileJson.close();
        }

}

void files::tojs()
{
   // try{
        QFile fileJson("D:/shitforme/labs/2.json");

       /* if (!fileJson.exists()){
            throw 1;
        }*/

        if (fileJson.open(QIODevice::WriteOnly)){
        QVariantMap testMap;
        testMap.insert("Загальна кількість балів комп'ютера", gen_pc_bal);
        testMap.insert("Загальна кількість балів гравця", gen_me_bal);
        testMap.insert("Кількість балів комп'ютера", pc_bal);
        testMap.insert("Кількість балів гравця", me_bal);
        testMap.insert("Кількість голубів", pigeons);
        testMap.insert("Кількість яструбів", hawks);
        fileJson.write(QJsonDocument(QJsonObject::fromVariantMap(testMap)).toJson());
        fileJson.close();
        }

       // }

      /*  catch (int e) {
            QMessageBox::about(this, "Помилка", "Файл не відкрився!");
            qApp->exit();
        }*/
}
