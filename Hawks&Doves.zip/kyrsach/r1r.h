#ifndef R1R_H
#define R1R_H

#include <QDialog>

#include "files1.h"

namespace Ui {
class r1r;
}

class r1r : public QDialog
{
    Q_OBJECT

public:
    explicit r1r(QString data, QWidget *parent = nullptr);
    ~r1r();

private slots:
    void on_nextround_clicked();

    QString compare();

private:
    int m;
    QString mstr;

    files1 *Files1;
    Ui::r1r *ui;
};

#endif // R1R_H
