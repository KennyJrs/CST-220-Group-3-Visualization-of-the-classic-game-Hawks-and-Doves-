#ifndef AMOUNT_H
#define AMOUNT_H

#include <QDialog>

#include "r1.h"

namespace Ui {
class amount;
}

class amount : public QDialog
{
    Q_OBJECT

public:
    explicit amount(QWidget *parent = nullptr);
    ~amount();

private slots:

    void ott();

private:
    int val = 0;
    Ui::amount *ui;
};

#endif // AMOUNT_H
