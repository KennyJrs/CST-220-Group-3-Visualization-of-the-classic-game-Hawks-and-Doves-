#include "r1r.h"
#include "ui_r1r.h"

#include "r1.h"
#include "rez.h"

#include <QFile>
#include <QRegExp>
#include <QMessageBox>
#include <QStringList>


r1r::r1r(QString data, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::r1r)
{
    m = data.toInt();
    mstr = data;
    files1 *Files1 = new files1;
   //if (yy<m) {
    if (Files1->roundsfromjs()-1 < m){
    setWindowTitle("Результат раунда");
    ui->setupUi(this);
    ui->label_4->setText(QString::number(Files1->roundsfromjs()-1));
    ui->label_5->setText(Files1->getfromjs());
    ui->label_6->setText(compare());
    //yy++;
    Files1->set_rounds(Files1->roundsfromjs()-1+1);
   }
   //else if (yy==m) {
    else if (Files1->roundsfromjs()-1 == m){
       setWindowTitle("Результат раунда");
       ui->setupUi(this);
       ui->nextround->setText("Результат гри");
       ui->label_4->setText(QString::number(Files1->roundsfromjs()-1));
       ui->label_5->setText(Files1->getfromjs());
       ui->label_6->setText(compare());
       //yy++;
       Files1->set_rounds(Files1->roundsfromjs()-1+1);
   }
   delete Files1;
}

r1r::~r1r()
{
    delete ui;
}

void r1r::on_nextround_clicked()
{
    files1 *Files1 = new files1;
    this->close();
    //if (yy <= m){
    if (Files1->roundsfromjs() <= m) {
     r1* round1 = new r1(mstr);
     round1->exec();
    }
     else {
     rez* rz = new rez();
     rz->exec();
    }
    delete Files1;
}

QString r1r::compare()
{
       try {
       QStringList wordList;
        QFile f("D:/labs/kyrsach/resources/scores.json");

        if (!f.exists()){
            throw 1;
        }

          if (f.open(QIODevice::ReadOnly))
          {
               QString data1;
               data1 = f.readAll();
               QRegExp rx("[:,}]");
               wordList = data1.split(rx);
               f.close();
          }
          QString str1 = wordList[5] + " " + wordList[7];
          if (str1.split(" ")[1].toInt() < str1.split(" ")[3].toInt())
          {
                QString str4 = "Ви програли!";
                return str4;
          }
          if (str1.split(" ")[1].toInt() > str1.split(" ")[3].toInt())
          {
                QString str4 = "Ви перемогли!";
                return str4;
          }
          if (str1.split(" ")[1].toInt() == str1.split(" ")[3].toInt())
          {
                QString str4 = "Перемогла дружба!";
                return str4;
          }
          }
        catch (int e){
            QMessageBox::about(this, "Помилка", "Файл не відкрився!");
            qApp->exit();
        }
          return 0;
}

