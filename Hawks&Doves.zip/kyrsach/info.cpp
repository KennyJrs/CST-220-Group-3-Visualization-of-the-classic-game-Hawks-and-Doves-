#include "info.h"
#include "ui_info.h"

info::info(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::info)
{
    ui->setupUi(this);
    setWindowTitle("Інформація");
}

info::~info()
{
    delete ui;
}

void info::on_ok_clicked()
{
    this->close();
}

