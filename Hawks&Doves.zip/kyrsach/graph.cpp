#include "graph.h"
#include "ui_graph.h"

#include <QVector>

graph::graph(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::graph)
{
    ui->setupUi(this);

    xstep = 1;
    xbegin = -10;
    xend = 10;

    ui->widget->xAxis->setRange(-20, 20);
    ui->widget->yAxis->setRange(-20, 20);
}

graph::~graph()
{
    delete ui;
}
