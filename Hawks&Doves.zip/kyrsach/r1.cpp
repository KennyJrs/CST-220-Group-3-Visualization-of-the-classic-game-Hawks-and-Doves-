#include "r1.h"
#include "ui_r1.h"

#include "r1r.h"

#include <QMessageBox>


r1::r1(QString data,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::r1)
{
    try{
    QString vname = typeid (data).name();
        if (vname == "i")
            throw 1;
        if (vname == "d")
            throw 2;
        if (vname == "f")
            throw 3;

        files1 *Files1 = new files1;
        n = data.toInt();
        nstr = data;
       // if (i<=n) {
        if (Files1->roundsfromjs() <= n){
            ui->setupUi(this);
            ui->label_3->setText(QString::number(Files1->roundsfromjs()));
            //i++;
            Files1->set_rounds(Files1->roundsfromjs()+1);
            Files1->roundstojs();
            delete Files1;
        }
    }
    catch (int e) {
        if (e == 1){
            QMessageBox::about(this, "Помилка", "Некоректний тип данних(int)!");
            qApp->exit();
        }
        if (e == 2){
            QMessageBox::about(this, "Помилка", "Некоректний тип данних(double)!");
            qApp->exit();
        }
        if (e == 3){
            QMessageBox::about(this, "Помилка", "Некоректний тип данних(float)!");
            qApp->exit();
        }
    }
}

r1::~r1()
{
    delete ui;
}

void r1::on_vids_clicked()
{
    files1 *Files1 = new files1;

    Files1->set_me_vids(1);
    Files1->comp_str();
    Files1->point();
    Files1->set_me_vids(0);
    Files1->set_pc_vids(0);
    Files1->set_pc_attack(0);
    Files1->tojs();

    delete Files1;

    this->close();
    r1r* r1 = new r1r(nstr,this);
    r1->exec();
}


void r1::on_atack_clicked()
{
    files1 *Files1 = new files1;

    Files1->set_me_attack(1);
    Files1->comp_str();
    Files1->point();
    Files1->set_me_attack(0);
    Files1->set_pc_vids(0);
    Files1->set_pc_attack(0);
    Files1->tojs();

    delete Files1;

    this->close();
    r1r* r1 = new r1r(nstr,this);
    r1->exec();
}

