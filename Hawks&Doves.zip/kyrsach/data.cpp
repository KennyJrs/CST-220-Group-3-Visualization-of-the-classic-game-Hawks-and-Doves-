#include "data.h"

#include <QFile>
#include <QString>

#include <QVariantMap>
#include <QJsonDocument>
#include <QJsonObject>



data::data()
{

}

/*void data::to_js()
{
    QFile fileJson("D:/shitforme/labs/2.json");

    fileJson.open(QIODevice::WriteOnly);
    QVariantMap testMap;
    testMap.insert("Загальна кількість балів комп'ютера", gen_pc_bal);
    testMap.insert("Загальна кількість балів гравця", gen_me_bal);
    testMap.insert("Кількість балів комп'ютера", pc_bal);
    testMap.insert("Кількість балів гравця", me_bal);
    fileJson.write(QJsonDocument(QJsonObject::fromVariantMap(testMap)).toJson());
    fileJson.close();
}

QString data::from_js()
{
    QString fromjs;
    QFile file;
    file.setFileName("D:/shitforme/labs/2.json");
    file.open(QIODevice::ReadOnly | QIODevice::Text);
    fromjs = file.readAll();
    file.close();
    return fromjs;
}

void data::bal_from_csv()
{

}*/
