#ifndef FILES_H
#define FILES_H

#include <QString>

class files
{
public:
    files();
    ~files();
int get_me_bal();
int get_pc_bal();
int get_gen_me_bal();
int get_gen_pc_bal();
int get_pigeons();
int get_hawks();
int get_pc_vids();
int get_pc_attack();
int get_me_vids();
int get_me_attack();

void set_pc_vids(int i);
void set_pc_attack(int i);
void set_me_vids(int i);
void set_me_attack(int i);
void set_pigeons(int i);
void set_hawks(int i);

void set_me_bal(int i);
void set_pc_bal(int i);
void set_gen_me_bal(int i);
void set_gen_pc_bal(int i);

QString getfromjs();
QString fromcsv();
void tojs();
void point();
void comp_str();

void all();


private:
    int me_bal,pc_bal,gen_me_bal,gen_pc_bal,pigeons,hawks,pc_vids,pc_attack,me_vids,me_attack;
};

#endif // FILES_H
